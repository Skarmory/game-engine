class TCODLIB_GUI_API StatusBar : public Widget {
public :
	StatusBar(int x,int y,int w, int h):Widget(x,y,w,h) {}
	void render();
};

